import logo from './logo.svg';
import './App.css';
import AddProduct from './AddProduct';
import ProductList from './ProductList';

function App() {
  return (
    <div className="App">
      <AddProduct></AddProduct>
      <ProductList></ProductList>
    </div>
  );
}

export default App;
